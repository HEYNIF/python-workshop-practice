num1 = int(input("enter the first no: "))
num2 = int(input("enter the second no: "))

sum_of_num = num1 + num2
print("sum of two number is ", sum_of_num)

dif_of_num = num1 - num2

print("dif of two number is", dif_of_num)

product_of_num = num1 * num2
print("product of two number is ", product_of_num)


div_of_num = num1 / num2

print("div of two number is", div_of_num)