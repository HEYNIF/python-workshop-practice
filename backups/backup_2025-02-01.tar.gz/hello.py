name = input("Enter your name: ") #user sai input lesakte hai
name = "chacha"
env = "dev"
print("hello",name)
