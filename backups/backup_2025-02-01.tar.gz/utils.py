import os

print(os.system("df -h")) # print cpu usage

print(os.system('uptime')) #print uptime and load average of pc

print(os.system('sysctl hw.memsize')) # print ram usage ig

print(os.system('ls'))